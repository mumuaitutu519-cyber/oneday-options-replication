"""
Tests for setting options in KalmanFilter, KalmanSmoother, SimulationSmoother

(does not test the filtering, smoothing, or simulation smoothing for each
option)

Author: Chad Fulton
License: Simplified-BSD
"""

import numpy as np
from numpy.testing import assert_equal

from statsmodels.tsa.statespace.kalman_filter import (
    FILTER_AUGMENTED,
    FILTER_CHANDRASEKHAR,
    FILTER_COLLAPSED,
    FILTER_CONCENTRATED,
    FILTER_CONVENTIONAL,
    FILTER_EXACT_INITIAL,
    FILTER_EXTENDED,
    FILTER_SQUARE_ROOT,
    FILTER_UNIVARIATE,
    FILTER_UNSCENTED,
    INVERT_CHOLESKY,
    INVERT_LU,
    INVERT_UNIVARIATE,
    MEMORY_CONSERVE,
    MEMORY_NO_FILTERED,
    MEMORY_NO_FORECAST,
    MEMORY_NO_GAIN,
    MEMORY_NO_LIKELIHOOD,
    MEMORY_NO_PREDICTED,
    MEMORY_NO_SMOOTHING,
    MEMORY_NO_STD_FORECAST,
    MEMORY_STORE_ALL,
    SOLVE_CHOLESKY,
    SOLVE_LU,
    STABILITY_FORCE_SYMMETRY,
)
from statsmodels.tsa.statespace.kalman_smoother import (
    SMOOTHER_ALL,
    SMOOTHER_DISTURBANCE,
    SMOOTHER_DISTURBANCE_COV,
    SMOOTHER_STATE,
    SMOOTHER_STATE_AUTOCOV,
    SMOOTHER_STATE_COV,
)
from statsmodels.tsa.statespace.simulation_smoother import (
    SIMULATION_ALL,
    SIMULATION_STATE,
    SimulationSmoother,
)


def setup_model(*args, **kwargs):

    # Dummy data
    endog = np.arange(10)
    k_states = 1

    model = SimulationSmoother(*args, k_endog=1, k_states=k_states, **kwargs)
    model.bind(endog)
    return model


def test_filter_methods():
    model = setup_model()

    # TODO test FilterResults for accurante boolean versions of options
    # Clear the filter method
    model.filter_method = 0

    # Try setting via boolean
    model.filter_conventional = True
    assert_equal(model.filter_method, FILTER_CONVENTIONAL)

    model.filter_collapsed = True
    assert_equal(model.filter_method, FILTER_CONVENTIONAL | FILTER_COLLAPSED)
    model.filter_conventional = False
    assert_equal(model.filter_method, FILTER_COLLAPSED)

    # Try setting directly via method
    model.set_filter_method(FILTER_AUGMENTED)
    assert_equal(model.filter_method, FILTER_AUGMENTED)

    # Try setting via boolean via method
    model.set_filter_method(filter_conventional=True, filter_augmented=False)
    assert_equal(model.filter_method, FILTER_CONVENTIONAL)

    # Try setting and unsetting all
    model.filter_method = 0
    for name in model.filter_methods:
        setattr(model, name, True)
    assert_equal(
        model.filter_method,
        FILTER_CONVENTIONAL
        | FILTER_EXACT_INITIAL
        | FILTER_AUGMENTED
        | FILTER_SQUARE_ROOT
        | FILTER_UNIVARIATE
        | FILTER_COLLAPSED
        | FILTER_EXTENDED
        | FILTER_UNSCENTED
        | FILTER_CONCENTRATED
        | FILTER_CHANDRASEKHAR,
    )
    for name in model.filter_methods:
        setattr(model, name, False)
    assert_equal(model.filter_method, 0)


def test_inversion_methods():
    model = setup_model()

    # Clear the inversion method
    model.inversion_method = 0

    # Try setting via boolean
    model.invert_univariate = True
    assert_equal(model.inversion_method, INVERT_UNIVARIATE)
    model.invert_cholesky = True
    assert_equal(model.inversion_method, INVERT_UNIVARIATE | INVERT_CHOLESKY)
    model.invert_univariate = False
    assert_equal(model.inversion_method, INVERT_CHOLESKY)

    # Try setting directly via method
    model.set_inversion_method(INVERT_LU)
    assert_equal(model.inversion_method, INVERT_LU)

    # Try setting via boolean via method
    model.set_inversion_method(
        invert_cholesky=True, invert_univariate=True, invert_lu=False
    )
    assert_equal(model.inversion_method, INVERT_UNIVARIATE | INVERT_CHOLESKY)

    # Try setting and unsetting all
    model.inversion_method = 0
    for name in model.inversion_methods:
        setattr(model, name, True)
    assert_equal(
        model.inversion_method,
        INVERT_UNIVARIATE | SOLVE_LU | INVERT_LU | SOLVE_CHOLESKY | INVERT_CHOLESKY,
    )
    for name in model.inversion_methods:
        setattr(model, name, False)
    assert_equal(model.inversion_method, 0)


def test_stability_methods():
    model = setup_model()

    # Clear the stability method
    model.stability_method = 0

    # Try setting via boolean
    model.stability_force_symmetry = True
    assert_equal(model.stability_method, STABILITY_FORCE_SYMMETRY)
    model.stability_force_symmetry = False
    assert_equal(model.stability_method, 0)

    # Try setting directly via method
    model.stability_method = 0
    model.set_stability_method(STABILITY_FORCE_SYMMETRY)
    assert_equal(model.stability_method, STABILITY_FORCE_SYMMETRY)

    # Try setting via boolean via method
    model.stability_method = 0
    model.set_stability_method(stability_method=True)
    assert_equal(model.stability_method, STABILITY_FORCE_SYMMETRY)

    # Try setting via keyword via method
    model.stability_method = 0
    model.set_stability_method(stability_force_symmetry=True)
    assert_equal(model.stability_method, STABILITY_FORCE_SYMMETRY)


def test_conserve_memory():
    model = setup_model()

    # Clear the filter method
    model.conserve_memory = MEMORY_STORE_ALL

    # Try setting via boolean
    model.memory_no_forecast = True
    assert_equal(model.conserve_memory, MEMORY_NO_FORECAST)
    model.memory_no_filtered = True
    assert_equal(model.conserve_memory, MEMORY_NO_FORECAST | MEMORY_NO_FILTERED)
    model.memory_no_forecast = False
    assert_equal(model.conserve_memory, MEMORY_NO_FILTERED)

    # Try setting directly via method
    model.set_conserve_memory(MEMORY_NO_PREDICTED)
    assert_equal(model.conserve_memory, MEMORY_NO_PREDICTED)

    # Try setting via boolean via method
    model.set_conserve_memory(memory_no_filtered=True, memory_no_predicted=False)
    assert_equal(model.conserve_memory, MEMORY_NO_FILTERED)

    # Try setting and unsetting all
    model.conserve_memory = 0
    for name in model.memory_options:
        if name == "memory_conserve":
            continue
        setattr(model, name, True)
    assert_equal(
        model.conserve_memory,
        MEMORY_NO_FORECAST
        | MEMORY_NO_PREDICTED
        | MEMORY_NO_FILTERED
        | MEMORY_NO_LIKELIHOOD
        | MEMORY_NO_GAIN
        | MEMORY_NO_SMOOTHING
        | MEMORY_NO_STD_FORECAST,
    )
    assert_equal(model.conserve_memory & MEMORY_CONSERVE, MEMORY_CONSERVE)
    for name in model.memory_options:
        if name == "memory_conserve":
            continue
        setattr(model, name, False)
    assert_equal(model.conserve_memory, 0)


def test_smoother_outputs():
    model = setup_model()

    # TODO test SmootherResults for accurante boolean versions of options

    # Clear the smoother output
    model.smoother_output = 0

    # Try setting via boolean
    model.smoother_state = True
    assert_equal(model.smoother_output, SMOOTHER_STATE)
    model.smoother_disturbance = True
    assert_equal(model.smoother_output, SMOOTHER_STATE | SMOOTHER_DISTURBANCE)
    model.smoother_state = False
    assert_equal(model.smoother_output, SMOOTHER_DISTURBANCE)

    # Try setting directly via method
    model.set_smoother_output(SMOOTHER_DISTURBANCE_COV)
    assert_equal(model.smoother_output, SMOOTHER_DISTURBANCE_COV)

    # Try setting via boolean via method
    model.set_smoother_output(smoother_disturbance=True, smoother_disturbance_cov=False)
    assert_equal(model.smoother_output, SMOOTHER_DISTURBANCE)

    # Try setting and unsetting all
    model.smoother_output = 0
    for name in model.smoother_outputs:
        if name == "smoother_all":
            continue
        setattr(model, name, True)
    assert_equal(
        model.smoother_output,
        SMOOTHER_STATE
        | SMOOTHER_STATE_COV
        | SMOOTHER_STATE_AUTOCOV
        | SMOOTHER_DISTURBANCE
        | SMOOTHER_DISTURBANCE_COV,
    )
    assert_equal(model.smoother_output, SMOOTHER_ALL)
    for name in model.smoother_outputs:
        if name == "smoother_all":
            continue
        setattr(model, name, False)
    assert_equal(model.smoother_output, 0)


def test_simulation_outputs():
    # TODO test changing simulation options in SimulationSmoothResults
    # instance
    model = setup_model()
    assert_equal(model.get_simulation_output(SIMULATION_STATE), SIMULATION_STATE)
    assert_equal(
        model.get_simulation_output(simulate_state=True, simulate_disturbance=True),
        SIMULATION_ALL,
    )
